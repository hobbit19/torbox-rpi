#!/bin/bash

# Show the system .onion hostname

current=$(</var/log/tor-count.txt) # Get the current number
previous=$(($current-1)) # Deduct 1 from the current number

if [ -e /var/lib/tor/$previous/hostname ]; then # If there is an origional .onion hostname
    cat /var/lib/tor/$previous/hostname # Get the origional .onion hostname
else # If there is no origional .onion hostname
    cat /var/lib/tor/$current/hostname # Get the current .onion hostname
fi


