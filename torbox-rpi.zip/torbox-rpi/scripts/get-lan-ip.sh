#!/bin/bash

# Show the system LAN IP address

hostname -I # Get the system LAN IP address
