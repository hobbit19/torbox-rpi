#!/bin/bash

# Change the system .onion hostname stage 1

current=$(</var/log/tor-count.txt) # Get the current number
next=$(($current+1)) # Get the next number
echo "1" > /var/log/tor-stage.txt # Update the stage file
echo $next > /var/log/tor-count.txt # Update the count file
mkdir /var/lib/tor/$next # Make the next hidden service directory
chown debian-tor:debian-tor /var/lib/tor/$next/ # Change ownership of the Tor hidden service directory
chmod 0700 /var/lib/tor/$next/ # Change the Tor hidden service directory permissions
echo "HiddenServiceDir /var/lib/tor/$next/" >> /etc/tor/torrc # Enable the Tor new hidden service directory
echo "HiddenServicePort 80 127.0.0.1:80" >> /etc/tor/torrc # Enable the Tor new hidden service port for Apache2


