#!/bin/bash

# Reboot the system

shutdown -r +1 "The system will reboot in 1 minute, please logout and wait a few minutes before trying to connect to the system again" # Reboot the system after 1 minute
