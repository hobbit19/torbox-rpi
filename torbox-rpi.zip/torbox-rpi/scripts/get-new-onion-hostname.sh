#!/bin/bash

# Show the new system .onion hostname

current=$(</var/log/tor-count.txt) # Get the current number
cat /var/lib/tor/$current/hostname # Get the new .onion hostname
