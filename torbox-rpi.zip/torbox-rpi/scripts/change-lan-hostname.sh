#!/bin/bash

# Change the system LAN hostname

rm /etc/hostname # Delte the hostname file  
touch /etc/hostname # Create the new hostname file
newhostname=$1 # Get the new hostname from the sys admin PHP page
echo $newhostname >> /etc/hostname # Write the new hostname to the new hostname file

rm /etc/hosts # Delte the hosts file    
touch /etc/hosts # Create the new hosts file
echo "127.0.0.1 localhost" >> /etc/hosts
ip=127.0.0.1
echo $ip $newhostname >> /etc/hosts # Write the new hostname to the new hosts file
echo "" >> /etc/hosts
echo "::1 localhost ip6-localhost ip6-loopback" >> /etc/hosts
echo "ff02::1 ip6-allnodes" >> /etc/hosts
echo "ff02::2 ip6-allrouters" >> /etc/hosts
