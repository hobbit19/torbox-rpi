#!/bin/bash

# Show the system LAN MAC address

cat /sys/class/net/$(ip route show default | awk '/default/ {print $5}')/address # Get the system LAN MAC address
