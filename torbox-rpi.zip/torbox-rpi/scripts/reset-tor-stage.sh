#!/bin/bash

# Reset the Tor stage

echo "0" > /var/log/tor-stage.txt # Update the stage file
