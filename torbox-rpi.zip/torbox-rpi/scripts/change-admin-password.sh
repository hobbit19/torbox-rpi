#!/bin/bash

# Change the system administration and OS passwords

newpassword=$1 # Get the new system administration password from sys admin PHP page
newpasswordhash=$2 # Get the new system administration password hash from sys admin PHP page
echo -e "$newpassword\n$newpassword" | passwd pi # Set the new OS password for user pi
sed -i -e '/torbox/s/.*/  torbox : '"$newpasswordhash"'/g' /var/www/html/user/plugins/private/private.yaml # Update the new system administration passowrd
