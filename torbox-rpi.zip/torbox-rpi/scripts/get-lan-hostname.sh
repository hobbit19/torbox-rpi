#!/bin/bash

# Show the system LAN hostname

cat /etc/hostname # Get the system LAN hostname
