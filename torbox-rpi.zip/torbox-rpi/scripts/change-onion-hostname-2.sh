#!/bin/bash

# Change the system .onion hostname stage 1

current=$(</var/log/tor-count.txt) # Get the current number
removenum=$(($current-1)) # Get the previous number
rm -r /var/lib/tor/$removenum # Remove the previous directory and files
rm /etc/tor/torrc # Delete the Tor configuration file
touch /etc/tor/torrc # Create the new Tor configuration file
echo "HiddenServiceDir /var/lib/tor/$current/" >> /etc/tor/torrc # Enable the Tor hidden service directory
echo "HiddenServicePort 80 127.0.0.1:80" >> /etc/tor/torrc # Enable the Tor hidden service port for Apache2
echo "3" > /var/log/tor-stage.txt # Update the stage file

