#!/bin/bash

# Check the Tor stage

current=$(</var/log/tor-count.txt) # Get the current number
previous=$(($current-1)) # Get the previous number
stage=$(</var/log/tor-stage.txt) # Get the current stage

if [ -e /var/lib/tor/$current/hostname ] && [ -e /var/lib/tor/$previous/hostname ] && [ $stage == "1" ]; then # If a new .onion hostname has been generated update the Tor stage (System has been rebooted)
    echo "2" > /var/log/tor-stage.txt # Update the stage file
fi
