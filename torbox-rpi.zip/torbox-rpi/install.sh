#!/bin/bash

# TorBox installer V1.0

# Requirements: Raspberry Pi 3 B with Raspbian Lite (No updates) & SSH enabled and internet access via Ethernet (No WiFi for security)
# Please remember to make this script executable by running: chmod 755 install.sh
# To execute this script please run: sudo ./install.sh

clear
echo
echo "TorBox installer by Eclipse Web Services"
echo "Web: kc5uqjh6rls5qoiu.onion"
echo "Email: eclipsewebservices@protonmail.com"
echo
echo "Welcome to the TorBox installer !"
echo
echo "This version of the TorBox installer is only for the Raspberry Pi model 3 B with a clean install of Raspbian Lite"
echo
echo "The TorBox installer will download, install and configure the below:"
echo
echo "Apache2"
echo "PHP7"
echo "Tor"
echo "Grav"
echo

read -p "Do you want to run the TorBox installer now ? (y/n) " START # Prompt the user to start the installer
if [ "$START" = "y" ]; then # Start the installer
    echo
    echo "OK - Starting the TorBox installation";
    echo
    echo "Carrying out pre installation checks"
    echo

    # Pre installation checks

    # Check Apache2 is not already installed

    echo "Checking for Apache2"
    echo
    if [ -e /etc/apache2/apache2.conf ]; then # If Apache2 is already installed
        echo "Sorry, the TorBox installer could not continue, Apache2 is already installed !"
        echo
        exit
    else # If Apache2 is not already installed
        echo "Apache2 not already installed - OK"
        echo
    fi

    # Check PHP7 is not already installed

    echo "Checking for PHP7"
    echo
    if [ -e /etc/php/7.0/apache2/php.ini ]; then # If PHP7 is already installed
        echo "Sorry, the TorBox installer could not continue, PHP7 is already installed !"
        echo
        exit
    else # If PHP7 is not already installed
        echo "PHP7 not already installed - OK"
        echo
    fi

    # Check Tor is not already installed

    echo "Checking for Tor"
    echo
    if [ -e /var/lib/tor/hidden_service/hostname ]; then # If Tor is already installed
        echo "Sorry, the TorBox installer could not continue, Tor is already installed !"
        echo
        exit
    else # If Tor is not already installed
        echo "Tor not already installed - OK"
        echo
    fi

    # If all pre installation checks are ok

    echo "All pre installation checks - OK"
    echo

    # Update sources

    echo "Updating sources"
    echo
    apt-get update # Update the sources
    echo
    echo "Updated sources - OK"
    echo

    # Install Apache2 with no user input prompts

    echo "Installing Apache2"
    echo
    apt-get install -y apache2 # Install Apache2
    echo
    echo "Installed Apache2 - OK"
    echo

    # Configure Apache2

    echo "Configuring Apache2"
    echo
    sed -i -e 's/Options Indexes FollowSymLinks/Options FollowSymLinks/g' /etc/apache2/apache2.conf # Stop Apache2 from displaying directory listings
    sed -i -z 's/AllowOverride None/AllowOverride All/3' /etc/apache2/apache2.conf # Allow use of the .htaccess file
    echo "" >> /etc/apache2/apache2.conf
    echo "ServerSignature Off" >> /etc/apache2/apache2.conf # Stop Apache2 from revealing the operating system
    echo "ServerTokens Prod" >> /etc/apache2/apache2.conf # Stop Apache2 from revealing it's self
    sed -i -e 's/Listen 80/Listen 127.0.0.1:80/g' /etc/apache2/ports.conf # Make Apache2 listen on port 80 only
    sed -i -e 's/<VirtualHost \*:80>/<VirtualHost 127.0.0.1:80>/g' /etc/apache2/sites-enabled/000-default.conf # Make Apache2 listen on localhost only
    a2enmod rewrite # Enable the rewrite module
    service apache2 restart # Restart Apache2
    echo "" >> /etc/sudoers
    echo "www-data ALL=NOPASSWD: /var/www/scripts/change-admin-password.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/get-lan-ip.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/get-lan-mac.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/get-lan-hostname.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/get-onion-hostname.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/get-new-onion-hostname.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/change-lan-hostname.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/check-tor-stage.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/reset-tor-stage.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/change-onion-hostname-1.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/change-onion-hostname-2.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo "www-data ALL=NOPASSWD: /var/www/scripts/reboot-system.sh" >> /etc/sudoers # Enable Apache2 to run the script
    echo
    echo "Configured Apache2 - OK"
    echo

    # Install PHP 7.0 with no user input prompts

    echo "Installing PHP 7.0"
    echo
    apt-get install -y php7.0 # Install PHP 7.0
    service apache2 restart # Restart Apache2
    echo
    echo "Installed PHP 7.0 - OK"
    echo

    # Configure PHP 7.0 with no user input prompts

    echo "Configuring PHP 7.0"
    echo
    apt-get install -y libapache2-mod-php7.0 # Install PHP 7.0 Apache2 mod
    apt-get install -y php7.0-zip # Install PHP 7.0 zip
    apt-get install -y php7.0-mbstring # Install PHP 7.0 mbstring
    apt-get install -y php7.0-gd # Install PHP 7.0 gd
    apt-get install -y php7.0-curl # Install PHP 7.0 curl
    apt-get install -y php7.0-xml # Install PHP 7.0 xml
    service apache2 restart # Restart Apache2
    echo
    echo "Configured PHP 7.0 - OK"
    echo

    # Install Tor with no user input prompts

    echo "Installing Tor"
    echo
    apt-get install -y tor # Install Tor
    echo
    echo "Installed Tor - OK"
    echo

    # Configure Tor

    echo "Configuring Tor - Please wait this may take some time"
    echo
    touch /var/log/tor-count.txt # Create the count file
    echo "1" >> /var/log/tor-count.txt # Set the count to 1
    touch /var/log/tor-stage.txt # Create the stage file
    echo "0" >> /var/log/tor-stage.txt # Set the stage to 0
    rm /etc/tor/torrc # Delete the Tor default configuration file
    touch /etc/tor/torrc # Create the new Tor configuration file
    echo "HiddenServiceDir /var/lib/tor/1/" >> /etc/tor/torrc # Enable the Tor hidden service directory
    echo "HiddenServicePort 80 127.0.0.1:80" >> /etc/tor/torrc # Enable the Tor hidden service port for Apache2
    mkdir /var/lib/tor/1/ # Create the Tor hidden service directory
    chown debian-tor:debian-tor /var/lib/tor/1/ # Change ownership of the Tor hidden service directory
    chmod 0700 /var/lib/tor/1/ # Change the Tor hidden service directory permissions
    service apache2 restart # Restart Apache2
    until [ -e /var/lib/tor/1/hostname ]; do # Until the Tor hostname file has been generated    
    /etc/init.d/tor restart # Restart Tor
    sleep 10 # Pause for 10 seconds
    done
    echo
    echo "Configured Tor - OK"
    echo

    # Install Grav

    echo "Installing Grav"
    echo
    rm /var/www/html/index.html # Delete the default Apache2 index page
    cp -r html/. /var/www/html # Copy the files from the html directory
    echo "Installed Grav - OK"
    echo

    # Configure Grav

    echo "Configuring Grav"
    echo
    chmod 775 -R /var/www/html # Make the Grav directories and files writable
    chown ${USER}:www-data -R /var/www/html # Give Grav ownership to Apache2
    echo "Configured Grav - OK"
    echo

    # Copy scripts

    echo "Copying scripts"
    echo
    mkdir /var/www/scripts # Make the scripts directory
    cp -r scripts/. /var/www/scripts # Copy the files from the scripts directory
    chmod 755 /var/www/scripts/change-admin-password.sh # Make the script executable
    chmod 755 /var/www/scripts/get-lan-ip.sh # Make the script executable
    chmod 755 /var/www/scripts/get-lan-mac.sh # Make the script executable
    chmod 755 /var/www/scripts/get-lan-hostname.sh # Make the script executable
    chmod 755 /var/www/scripts/get-onion-hostname.sh # Make the script executable
    chmod 755 /var/www/scripts/get-new-onion-hostname.sh # Make the script executable
    chmod 755 /var/www/scripts/change-lan-hostname.sh # Make the script executable
    chmod 755 /var/www/scripts/check-tor-stage.sh # Make the script executable
    chmod 755 /var/www/scripts/reset-tor-stage.sh # Make the script executable
    chmod 755 /var/www/scripts/change-onion-hostname-1.sh # Make the script executable
    chmod 755 /var/www/scripts/change-onion-hostname-2.sh # Make the script executable
    chmod 755 /var/www/scripts/reboot-system.sh # Make the script executable
    echo "Copied scripts - oK"
    echo

    # Change the password

    echo "Changing password"
    echo
    echo -e "TorBox1234!\nTorBox1234!" | passwd pi # Set the new password
    echo
    echo "Changed password - OK"
    echo

    # Change the OS hostname

    echo "Changing hostname"
    echo
    rm /etc/hostname # Delte the hostname file
    host=$(cat /dev/urandom | tr -dc 'a-z0-9' | fold -w 8 | head -n 1) # Generate a new 8 character random OS hostname
    touch /etc/hostname # Create the new hostname file
    echo $host >> /etc/hostname # Write the new hostname to the new hostname file
    rm /etc/hosts # Delte the hosts file
    touch /etc/hosts # Create the new hosts file
    echo "127.0.0.1 localhost" >> /etc/hosts
    ip=127.0.0.1
    echo $ip $host >> /etc/hosts # Write the new hostname to the new hosts file
    echo "" >> /etc/hosts
    echo "::1 localhost ip6-localhost ip6-loopback" >> /etc/hosts
    echo "ff02::1 ip6-allnodes" >> /etc/hosts
    echo "ff02::2 ip6-allrouters" >> /etc/hosts
    echo "Changed hostname - OK"
    echo

    # Disable SSH

    echo "Disabling SSH"
    echo
    systemctl disable ssh.service # Disable SSH
    echo
    echo "Disabled SSH - OK"
    echo

    # Installation complete

    echo "Finishing installation please wait"
    echo
    echo "Installed TorBox - OK"
    echo
    echo "Your new .onion hostname is below, you can now visit it using the Tor browser to setup your new .onion website"
    echo
    cat /var/lib/tor/1/hostname # Get the new .onion hostname
    echo
    echo "For full functionality when using Grav we recommend allowing scripts in the Tor browser for your .onion website"
    echo
    echo "If you found the TorBox installer usefull please consider supporting us by donating in Bitcoin to: 1kcrttMQZQSZ9UixDP9BCF59W9Mihgg4X or by PayPal to: eclipsewebservices@protonmail.com"
    echo
    read -p "The system now needs to reboot, for security after rebooting you will no longer be able to connect by SSH, you will have to physically connect a keyboard and monitor and use the username: pi and password: TorBox1234! reboot now ? (y/n) " REBOOT # Prompt the user to reboot
    if [ "$REBOOT" = "y" ]; then # Reboot
        echo
        echo "Rebooting system"
        echo
        sleep 5 # Pause for 5 seconds
        reboot
    else
        echo
        echo "OK - Please reboot the system when you are ready"
        echo
    fi

else # Do not start the installer
    echo
    echo "OK - Please run the TorBox installer again when you are ready";
    echo
fi
