<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/var/www/html/user/plugins/admin/languages/tlh.yaml',
    'modified' => 1513004450,
    'data' => [
        'PLUGIN_ADMIN' => [
            'LOGIN_BTN_FORGOT' => 'lIj',
            'BACK' => 'chap',
            'NORMAL' => 'motlh',
            'YES' => 'HIja\'',
            'NO' => 'Qo\'',
            'DISABLED' => 'Qotlh'
        ]
    ]
];
