<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://private/private.yaml',
    'modified' => 1513158641,
    'data' => [
        'enabled' => true,
        'routes' => [
            'login' => '/login',
            'logout' => '/logout'
        ],
        'session_ss' => 'random_value',
        'private_site' => false,
        'private_tag' => 'hidden',
        'enable_username' => true,
        'users' => [
            'torbox' => '01a5e0639636d8d0cc336b2e079e778d222d15d5'
        ],
        'texts' => [
            'h1' => 'System Administration',
            'h2' => 'Please <strong>login</strong>'
        ],
        'fields' => [
            'username' => [
                'label' => 'Username',
                'placeholder' => 'Enter your username'
            ],
            'password' => [
                'label' => 'Password',
                'placeholder' => 'Enter your password'
            ],
            'antispam' => [
                'label' => 'Antispam',
                'placeholder' => 'Please leave this field empty for Antispam'
            ],
            'login' => [
                'label' => 'Login'
            ]
        ],
        'messages' => [
            'success' => 'You are logged.',
            'error' => 'Oops! There was a problem with your submission. Please try again or <a href=\'https://github.com/Diyzzuf/grav-plugin-private/issues\' target=\'_blank\'>report an issue </a>',
            'fail' => 'Oops! Something went wrong.. Try Again !'
        ]
    ]
];
