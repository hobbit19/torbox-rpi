<?php

/* @Page:/var/www/html/user/pages/03.contact */
class __TwigTemplate_85796fbbbaf1361e22b999c059b0727df0388ab475c43d8de94bd3fc50ce0ef0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s7atb0\" style=\"text-align: left;\">Contact</h1>
<p>Email: <a href=\"mailto:eclipsewebservices@protonmail.com\">eclipsewebservices@protonmail.com</a></p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/03.contact";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s7atb0\" style=\"text-align: left;\">Contact</h1>
<p>Email: <a href=\"mailto:eclipsewebservices@protonmail.com\">eclipsewebservices@protonmail.com</a></p>", "@Page:/var/www/html/user/pages/03.contact", "");
    }
}
