<?php

/* @Page:/var/www/html/user/pages/01.home */
class __TwigTemplate_e1b23a4d114f17207c138f34dfb12e0a2c2bfd87040787fce67d9fb905b33aeb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services, the easy and secure way to host your own Tor .onion hidden service with a simple to use content management system for publishing your website.</p>
<p>You can login to the Grav content management system administration area to edit, add or delete pages etc. using the link below and the username: torbox and password: TorBox1234! (You should change this password immediatley for security)</p>
<p><a href=\"../../admin\">Grav Admin</a></p>
<p>For more information on using the Grav content management system please use the following link: <a href=\"https://learn.getgrav.org/\" target=\"_blank\" rel=\"noopener\">Learn Grav</a></p>
<p>The TorBox system administration area can be logged into using the link below and the username: torbox and password:&nbsp;TorBox1234! (You should change this password immediatley for security) also once logged in for privacy you may want to initially generate a new .onion hostname</p>
<p><a href=\"../../sysadmin\">TorBox System Admin</a></p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/01.home";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services, the easy and secure way to host your own Tor .onion hidden service with a simple to use content management system for publishing your website.</p>
<p>You can login to the Grav content management system administration area to edit, add or delete pages etc. using the link below and the username: torbox and password: TorBox1234! (You should change this password immediatley for security)</p>
<p><a href=\"../../admin\">Grav Admin</a></p>
<p>For more information on using the Grav content management system please use the following link: <a href=\"https://learn.getgrav.org/\" target=\"_blank\" rel=\"noopener\">Learn Grav</a></p>
<p>The TorBox system administration area can be logged into using the link below and the username: torbox and password:&nbsp;TorBox1234! (You should change this password immediatley for security) also once logged in for privacy you may want to initially generate a new .onion hostname</p>
<p><a href=\"../../sysadmin\">TorBox System Admin</a></p>", "@Page:/var/www/html/user/pages/01.home", "");
    }
}
