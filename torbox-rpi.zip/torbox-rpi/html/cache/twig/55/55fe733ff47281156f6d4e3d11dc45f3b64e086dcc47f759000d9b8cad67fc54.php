<?php

/* @Page:/var/www/html/user/pages/sysadmin */
class __TwigTemplate_398a45e6a247cc90e441c9e3c189ad6a9b09f3c4f34a42ad5959aa2984e168bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c1551chj0\">System Administration</h1>
<p style=\"text-align: center;\"><span style=\"color: #ff0000;\"><strong>WARNING ! - Do not edit, rename or delete this page, disable or remove the SysAdmin or Private plugins or disable twig or enable caching for this page from within the Grav admin area</strong></span></p>
<hr />
<p><a href=\"../../logout\">Logout System Administration</a></p>
<p>";
        // line 5
        echo $this->env->getExtension('Grav\Plugin\SysAdminTwigExtension')->sysadminFunction();
        echo "</p>
<hr />
<p style=\"text-align: center;\">If you find TorBox useful please consider helping to support us by spreading the word or donating in Bitcoin to:&nbsp;1kcrttMQZQSZ9UixDP9BCF59W9Mihgg4X or by PayPal to: eclipsewebservices@protonmail.com</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/sysadmin";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c1551chj0\">System Administration</h1>
<p style=\"text-align: center;\"><span style=\"color: #ff0000;\"><strong>WARNING ! - Do not edit, rename or delete this page, disable or remove the SysAdmin or Private plugins or disable twig or enable caching for this page from within the Grav admin area</strong></span></p>
<hr />
<p><a href=\"../../logout\">Logout System Administration</a></p>
<p>{{ sysadmin() }}</p>
<hr />
<p style=\"text-align: center;\">If you find TorBox useful please consider helping to support us by spreading the word or donating in Bitcoin to:&nbsp;1kcrttMQZQSZ9UixDP9BCF59W9Mihgg4X or by PayPal to: eclipsewebservices@protonmail.com</p>", "@Page:/var/www/html/user/pages/sysadmin", "");
    }
}
