<?php

/* @Page:/var/www/html/user/pages/01.home */
class __TwigTemplate_137409b2e247318376bbea59876b3db29afe5d5d35ae312f8ba5d65bfbde82f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services, the easy and secure way to host your own Tor .onion hidden service.</p>
<p>You can login to the Grav content management system admin area to edit, add or delete pages etc. using the link below and the username: torbox and password: TorBox1234! (You should change this password immediatley)</p>
<p><a href=\"../../admin\">Grav Admin</a></p>
<p>For more information on using the Grav content management system please use the following link: <a href=\"https://learn.getgrav.org/\" target=\"_blank\" rel=\"noopener\">Learn Grav</a></p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/01.home";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services, the easy and secure way to host your own Tor .onion hidden service.</p>
<p>You can login to the Grav content management system admin area to edit, add or delete pages etc. using the link below and the username: torbox and password: TorBox1234! (You should change this password immediatley)</p>
<p><a href=\"../../admin\">Grav Admin</a></p>
<p>For more information on using the Grav content management system please use the following link: <a href=\"https://learn.getgrav.org/\" target=\"_blank\" rel=\"noopener\">Learn Grav</a></p>", "@Page:/var/www/html/user/pages/01.home", "");
    }
}
