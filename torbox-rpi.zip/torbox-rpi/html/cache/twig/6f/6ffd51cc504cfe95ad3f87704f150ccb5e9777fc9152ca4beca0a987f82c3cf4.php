<?php

/* @Page:/var/www/html/user/pages/sysadmin */
class __TwigTemplate_3975f97aa78dd7c27d2b6e54fa7636e84ed212a3c465be598468a015f78e7fd4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c1551chj0\">System Administration</h1>
<p style=\"text-align: center;\"><span style=\"color: #ff0000;\"><strong>WARNING ! - Do not edit or delete this page or disable or delete the SysAdmin or Private plugins from within the Grav admin panel</strong></span></p>
<p><a href=\"../../logout\">Logout System Administration</a></p>
<p>";
        // line 4
        echo $this->env->getExtension('Grav\Plugin\ExampleTwigExtension')->exampleFunction();
        echo "</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/sysadmin";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  24 => 4,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c1551chj0\">System Administration</h1>
<p style=\"text-align: center;\"><span style=\"color: #ff0000;\"><strong>WARNING ! - Do not edit or delete this page or disable or delete the SysAdmin or Private plugins from within the Grav admin panel</strong></span></p>
<p><a href=\"../../logout\">Logout System Administration</a></p>
<p>{{ example() }}</p>", "@Page:/var/www/html/user/pages/sysadmin", "");
    }
}
