<?php

/* @Page:/var/www/html/user/pages/01.home */
class __TwigTemplate_96f645582e2062af7d72933e31f730f3a9303d47c593963cdd9580f522fff2f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services.</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/01.home";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services.</p>", "@Page:/var/www/html/user/pages/01.home", "");
    }
}
