<?php

/* @Page:/var/www/html/user/pages/03.contact */
class __TwigTemplate_3c7acfd7791034167a7f2b62679f80492f0642a0f261a9d3febac574cdc035f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s7atb0\" style=\"text-align: left;\">Contact</h1>
<p>This is a sample contact page.</p>
<p>Email: <a href=\"mailto:eclipsewebservices@protonmail.com\">eclipsewebservices@protonmail.com</a></p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/03.contact";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s7atb0\" style=\"text-align: left;\">Contact</h1>
<p>This is a sample contact page.</p>
<p>Email: <a href=\"mailto:eclipsewebservices@protonmail.com\">eclipsewebservices@protonmail.com</a></p>", "@Page:/var/www/html/user/pages/03.contact", "");
    }
}
