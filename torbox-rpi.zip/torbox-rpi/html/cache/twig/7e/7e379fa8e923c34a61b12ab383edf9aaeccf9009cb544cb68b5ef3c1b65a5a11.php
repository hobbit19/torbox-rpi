<?php

/* @Page:/var/www/html/user/pages/sysadmin */
class __TwigTemplate_7ea66f13f0c6b94d78109808351d10440e3c09ac4e41aff5872b91cbf7137197 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c1551chj0\">System Administration</h1>
<p style=\"text-align: center;\"><span style=\"color: #ff0000;\"><strong>WARNING ! - Do not edit, rename or delete this page, disable or remove the SysAdmin or Private plugins or disable twig or enable caching for this page from within the Grav admin console</strong></span></p>
<hr />
<p><a href=\"../../logout\">Logout System Administration</a></p>
<p>";
        // line 5
        echo $this->env->getExtension('Grav\Plugin\SysAdminTwigExtension')->sysadminFunction();
        echo "</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/sysadmin";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 5,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c1551chj0\">System Administration</h1>
<p style=\"text-align: center;\"><span style=\"color: #ff0000;\"><strong>WARNING ! - Do not edit, rename or delete this page, disable or remove the SysAdmin or Private plugins or disable twig or enable caching for this page from within the Grav admin console</strong></span></p>
<hr />
<p><a href=\"../../logout\">Logout System Administration</a></p>
<p>{{ sysadmin() }}</p>", "@Page:/var/www/html/user/pages/sysadmin", "");
    }
}
