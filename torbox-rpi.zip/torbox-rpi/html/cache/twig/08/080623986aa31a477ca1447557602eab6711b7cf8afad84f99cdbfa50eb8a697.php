<?php

/* @Page:/var/www/html/user/pages/01.home */
class __TwigTemplate_0fd90cd442e6f03f91c7d1da312a1051e4da71269b714f04476f294dac92b24a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox by Eclipse Web Services.</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/01.home";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox by Eclipse Web Services.</p>", "@Page:/var/www/html/user/pages/01.home", "");
    }
}
