<?php

/* @Page:/var/www/html/user/pages/02.about */
class __TwigTemplate_3b20881cf74fe2e445be306e831434683e4fba0a7529df4251133113dbf1f57e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s645m0\" style=\"text-align: left;\">About</h1>
<p>This is the about page.</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/02.about";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s645m0\" style=\"text-align: left;\">About</h1>
<p>This is the about page.</p>", "@Page:/var/www/html/user/pages/02.about", "");
    }
}
