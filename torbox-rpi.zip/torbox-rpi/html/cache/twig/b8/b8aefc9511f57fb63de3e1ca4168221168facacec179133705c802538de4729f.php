<?php

/* @Page:/var/www/html/user/plugins/private/pages */
class __TwigTemplate_25d883c19ebefc44fc2b40ba3004885526e485131b3d0c182c08e1e1cd35bbfc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<p>Login Page</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/plugins/private/pages";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<p>Login Page</p>", "@Page:/var/www/html/user/plugins/private/pages", "");
    }
}
