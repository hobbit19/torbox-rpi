<?php

/* @Page:/var/www/html/user/pages/01.home */
class __TwigTemplate_2074dc07caa88906d4edccfdbd2e1d7f3345c1e8f910d8d3ac33a20558a55596 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services, the easy and secure way to host your own Tor .onion hidden service on your own dedicated hardware with a simple to use content management system for publishing your anonymous website or blog etc.</p>
<p>You can login to the Grav content management system administration area to edit, add or delete pages etc. using the link below and the username: torbox and password: TorBox1234! (You should change this password immediately for security)&nbsp;For full functionality of Grav we recommend allowing scripts in the Tor browser for your .onion site. For more information on using the Grav content management system please use the following link: <a href=\"https://learn.getgrav.org/\" target=\"_blank\" rel=\"noopener\">Learn Grav</a></p>
<p><a href=\"../../admin\">Grav Admin</a> (Please bookmark this link for your&nbsp;convenience)</p>
<p>The TorBox system administration area can be logged into using the link below and the username: torbox and password:&nbsp;TorBox1234! (You should change this password&nbsp;immediately for security) also once logged in for privacy you may want to initially generate a new .onion hostname.</p>
<p><a href=\"../../sysadmin\">TorBox System Admin</a>&nbsp;(Please bookmark this link for your&nbsp;convenience)</p>
<p>For security to login to the actual operating system you will have to&nbsp;physically connect a keyboard and monitor and use the username: pi and password: TorBox1234!&nbsp;(You should consider changing this password for additional secuirty by running the command: passwd).</p>
<p>We hope you enjoy your new found privacy and anonymity using TorBox and if you find it useful please consider helping to support us by spreading the word or donating in Bitcoin to:&nbsp;1kcrttMQZQSZ9UixDP9BCF59W9Mihgg4X or by PayPal to: eclipsewebservices@protonmail.com</p>
<p>TorBox or Eclipse Web Services are not associated with the <a href=\"https://www.torproject.org/\" target=\"_blank\" rel=\"noopener\">Tor Project</a> or <a href=\"https://getgrav.org/\" target=\"_blank\" rel=\"noopener\">Grav</a>.</p>
<p>Many thanks, <a href=\"http://kc5uqjh6rls5qoiu.onion\" target=\"_blank\" rel=\"noopener\">Eclipse Web Services</a>.</p>";
    }

    public function getTemplateName()
    {
        return "@Page:/var/www/html/user/pages/01.home";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1 id=\"mcetoc_1c17s4tb10\" style=\"text-align: left;\">Welcome</h1>
<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"home/tor.png\" alt=\"Tor\" width=\"189\" height=\"192\" /></p>
<h1 id=\"mcetoc_1c133fjc30\">TorBox</h1>
<p>Welcome to TorBox from Eclipse Web Services, the easy and secure way to host your own Tor .onion hidden service on your own dedicated hardware with a simple to use content management system for publishing your anonymous website or blog etc.</p>
<p>You can login to the Grav content management system administration area to edit, add or delete pages etc. using the link below and the username: torbox and password: TorBox1234! (You should change this password immediately for security)&nbsp;For full functionality of Grav we recommend allowing scripts in the Tor browser for your .onion site. For more information on using the Grav content management system please use the following link: <a href=\"https://learn.getgrav.org/\" target=\"_blank\" rel=\"noopener\">Learn Grav</a></p>
<p><a href=\"../../admin\">Grav Admin</a> (Please bookmark this link for your&nbsp;convenience)</p>
<p>The TorBox system administration area can be logged into using the link below and the username: torbox and password:&nbsp;TorBox1234! (You should change this password&nbsp;immediately for security) also once logged in for privacy you may want to initially generate a new .onion hostname.</p>
<p><a href=\"../../sysadmin\">TorBox System Admin</a>&nbsp;(Please bookmark this link for your&nbsp;convenience)</p>
<p>For security to login to the actual operating system you will have to&nbsp;physically connect a keyboard and monitor and use the username: pi and password: TorBox1234!&nbsp;(You should consider changing this password for additional secuirty by running the command: passwd).</p>
<p>We hope you enjoy your new found privacy and anonymity using TorBox and if you find it useful please consider helping to support us by spreading the word or donating in Bitcoin to:&nbsp;1kcrttMQZQSZ9UixDP9BCF59W9Mihgg4X or by PayPal to: eclipsewebservices@protonmail.com</p>
<p>TorBox or Eclipse Web Services are not associated with the <a href=\"https://www.torproject.org/\" target=\"_blank\" rel=\"noopener\">Tor Project</a> or <a href=\"https://getgrav.org/\" target=\"_blank\" rel=\"noopener\">Grav</a>.</p>
<p>Many thanks, <a href=\"http://kc5uqjh6rls5qoiu.onion\" target=\"_blank\" rel=\"noopener\">Eclipse Web Services</a>.</p>", "@Page:/var/www/html/user/pages/01.home", "");
    }
}
