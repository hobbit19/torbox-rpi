# v1.0.9
## 09/09/2017

1. [](#improved)
   * Update Readme (#32)
   
# v1.0.8
## 05/06/2017

1. [](#improved)
   * Update changelog (#29)
   
# v1.0.7
## 02/06/2017

1. [](#improved)
   * Update blueprints ( Thanks @PeterTonoli ) and version number

# v1.0.6
## 02/06/2017

1. [](#bugfix)
   * Fix #27

# v1.0.5
## 22/04/2017

1. [](#changes)
   * Works, but Not Maintained / Enhancement ( Because [future] feature of pro version of Grav Admin Plugin ) => ( As long as I do not have the agreement of the team )

# v1.0.4
## 18/06/2016

1. [](#improved)
   * Add Little Doc Specification
   * Add Little Comments on `private.yaml`

# v1.0.3
## 02/01/2016

1. [](#bugfix)
    * Fix #9 #11 ( Thanks @ahmadassaf )
2. [](#improved)
    * Better Readme translation ( Thanks @mattarnster )

# v1.0.2
## 04/22/2015

1. [](#bugfix)
    * Delete Debug

# v1.0.1
## 04/21/2015

1. [](#new)
    * Rewrite Code

2. [](#bugfix)
    * Fix #3.2 bug when they are only one tag
    * Fix send login form route
    * Thanks Vaseltior

3. [](#improved)
    * "Improve" security
    * Home variable is now the same as system.yaml home variable
    * Update Documentation ( Need help for a best english documentation. )

# v0.4.6
## 03/10/2015

1. [](#bugfix)
    * Fix bug when the private tag is on first position
    * Fix #1 : Added var home on config for full private redirection 
    * Fix #2 : Compatibility sessions with other plugins 
    * (Thanks to Vivalldi)

2. [](#improved)
    * Update Documentation
    
# v0.4.5
## 02/18/2015

1. [](#new)
    * New Git Account for better monitoring

# v0.4.4
## 02/12/2015

1. [](#bugfix)
    * Fix conflict with other plugins (issue #1)
    * Fix bad commit, sorry ( 5991d5e )

# v0.4.3
## 02/12/2015

1. [](#bugfix)
    * ~~Fix conflict with other plugins (issue #1)~~
    ** This is a bad commit ! (  5991d5e ) **

# v0.4.2
## 02/10/2015

1. [](#bugfix)
    * US date on changelog

# v0.4.1
## 02/10/2015

1. [](#new)
    * Add redirect to referer page after login instead of home page
    * Release

2. [](#improved)
    * Better Documentation
    * Clean Code
    * Add parts of CSS
    * Clean repo

# v0.3.6
## 02/09/2015

1. [](#new)
    * Multi User
    * Add posibility to make private just certain page instead of full site

2. [](#improved)
    * Update Documentation
    * Clean Code


# v0.2.1
## 02/07/2015

1. [](#new)
    * Login page directly include on plugin
    * New Login Template

# v0.1.0
## 02/07/2015

1. [](#new)
    * First Commit
