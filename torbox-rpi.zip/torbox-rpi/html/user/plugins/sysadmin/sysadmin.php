<?php
namespace Grav\Plugin;
use \Grav\Common\Plugin;
class SysAdminPlugin extends Plugin
{
    public static function getSubscribedEvents()
    {
        return [
            'onTwigExtensions' => ['onTwigExtensions', 0]
        ];
    }
    public function onTwigExtensions()
    {
        require_once(__DIR__ . '/twig/SysAdminTwigExtension.php');
        $this->grav['twig']->twig->addExtension(new SysAdminTwigExtension());
    }
}
